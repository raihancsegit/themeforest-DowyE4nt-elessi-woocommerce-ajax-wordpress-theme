<?php
function nasa_hfe_footer_dark() {
    return array(
        'post' => array(
            'post_title' => 'HFE Footer Dark',
            'post_name' => 'hfe-footer-dark'
        ),
        
        'post_meta' => array(
            '_elementor_data' => '[{"id":"1d65169f","elType":"section","settings":{"css_classes":"text-center footer-darker padding-top-30"},"elements":[{"id":"eb9ee93","elType":"column","settings":{"_column_size":100,"_inline_size":null},"elements":[{"id":"104e66f","elType":"widget","settings":{"wp":{"image":"1703","alt":"","link_text":"#","link_target":"","align":"","hide_in_m":"","el_class":"margin-bottom-10"}},"elements":[],"widgetType":"wp-widget-nasa_image"},{"id":"5bc842bd","elType":"widget","settings":{"wp":{"title":"","text":"<p class=\"text-center margin-bottom-0\" style=\"font-weight: 600;\">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s. Lorem ipsum dolor sit amet, consectetur Nulla fringilla purus Lorem ipsum dosectetur adipisicing elit at leo dignissim congue. Mauris elementum accumsan leo vel tempor.<\/p>","filter":"on","visual":"on"}},"elements":[],"widgetType":"wp-widget-text"},{"id":"716536e4","elType":"widget","settings":{"wp":{"title":"","twitter":"","facebook":"","pinterest":"","email":"","instagram":"","rss":"","linkedin":"","youtube":"","flickr":"","telegram":"","whatsapp":"","amazon":"","tumblr":"","el_class":"margin-top-15"}},"elements":[],"widgetType":"wp-widget-nasa_follow"},{"id":"21973d14","elType":"widget","settings":{"wp":{"title":"","menu":"footer-menu","el_class":"nasa-menu-inline margin-top-10"},"_css_classes":"margin-bottom-0"},"elements":[],"widgetType":"wp-widget-nasa_menu_sc"},{"id":"b304553","elType":"widget","settings":{"html":"<p class=\"margin-bottom-0 padding-top-20 padding-bottom-30\">\u00a9 ' . date('Y') . ' - All Right reserved!<\/p>"},"elements":[],"widgetType":"html"}],"isInner":false}],"isInner":false}]',
            '_elementor_css' => 'a:7:{s:4:"time";i:1647680986;s:5:"fonts";a:0:{}s:5:"icons";a:0:{}s:20:"dynamic_elements_ids";a:0:{}s:6:"status";s:5:"empty";i:0;s:0:"";s:3:"css";s:0:"";}',
        ),

        'css' => ''
    );
}
