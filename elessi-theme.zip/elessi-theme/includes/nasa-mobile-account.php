<script type="text/template" id="tmpl-nasa-mobile-account">
    <div class="content-account">
        <?php echo elessi_tiny_account(true); ?>
    </div>
</script>
